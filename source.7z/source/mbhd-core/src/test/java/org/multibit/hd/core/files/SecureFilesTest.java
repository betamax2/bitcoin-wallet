package org.multibit.hd.core.files;


public class SecureFilesTest {

  // TODO (GR) Verify operation
  public void testSecureDelete() {



  }

}
