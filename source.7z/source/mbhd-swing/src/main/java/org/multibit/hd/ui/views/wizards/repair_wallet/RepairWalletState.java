package org.multibit.hd.ui.views.wizards.repair_wallet;

/**
 * <p>Enum to provide the following to "repair wallet" wizard model:</p>
 * <ul>
 * <li>State identification</li>
 * </ul>
 *
 * @since 0.0.1
 *
 */
public enum RepairWalletState {

  REPAIR_WALLET,
  REPAIR_WALLET_REPORT

  // End of enum
  ;

}
