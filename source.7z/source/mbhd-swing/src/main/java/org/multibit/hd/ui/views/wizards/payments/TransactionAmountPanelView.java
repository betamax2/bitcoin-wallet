package org.multibit.hd.ui.views.wizards.payments;

import com.google.common.base.Optional;
import com.google.common.base.Strings;
import net.miginfocom.swing.MigLayout;
import org.bitcoinj.core.Coin;
import org.multibit.hd.core.config.BitcoinConfiguration;
import org.multibit.hd.core.config.Configurations;
import org.multibit.hd.core.config.LanguageConfiguration;
import org.multibit.hd.core.dto.FiatPayment;
import org.multibit.hd.core.dto.PaymentData;
import org.multibit.hd.core.dto.TransactionData;
import org.multibit.hd.core.services.CoreServices;
import org.multibit.hd.core.services.WalletService;
import org.multibit.hd.core.store.TransactionInfo;
import org.multibit.hd.ui.events.view.ViewEvents;
import org.multibit.hd.ui.languages.Formats;
import org.multibit.hd.ui.languages.Languages;
import org.multibit.hd.ui.languages.MessageKey;
import org.multibit.hd.ui.views.components.LabelDecorator;
import org.multibit.hd.ui.views.components.Labels;
import org.multibit.hd.ui.views.components.Panels;
import org.multibit.hd.ui.views.components.panels.PanelDecorator;
import org.multibit.hd.ui.views.fonts.AwesomeIcon;
import org.multibit.hd.ui.views.themes.Themes;
import org.multibit.hd.ui.views.wizards.AbstractWizard;
import org.multibit.hd.ui.views.wizards.AbstractWizardPanelView;
import org.multibit.hd.ui.views.wizards.WizardButton;

import javax.swing.*;
import java.text.DecimalFormat;

/**
 * <p>View to provide the following to UI:</p>
 * <ul>
 * <li>Show transaction overview</li>
 * </ul>
 *
 * @since 0.0.1
 */
public class TransactionAmountPanelView extends AbstractWizardPanelView<PaymentsWizardModel, TransactionOverviewPanelModel> {

  private JLabel amountBTCLabel;
  private JLabel amountBTCValue;
  private JLabel amountFiatLabel;
  private JLabel amountFiatValue;
  private JLabel miningFeePaidLabel;
  private JLabel miningFeePaidValue;
  private JLabel miningFeePaidRateLabel;
  private JLabel miningFeePaidRateValue;
  private JLabel exchangeRateLabel;
  private JLabel exchangeRateValue;

  private final DecimalFormat feeRateFormat;

  /**
   * @param wizard The wizard managing the states
   */
  public TransactionAmountPanelView(AbstractWizard<PaymentsWizardModel> wizard, String panelName) {

    super(wizard, panelName, AwesomeIcon.FILE_TEXT_O, MessageKey.TRANSACTION_AMOUNT);

    feeRateFormat = new DecimalFormat("0.00");
  }

  @Override
  public void newPanelModel() {

    // Configure the panel model
    TransactionOverviewPanelModel panelModel = new TransactionOverviewPanelModel(
      getPanelName()
    );
    setPanelModel(panelModel);
  }

  @Override
  public void initialiseContent(JPanel contentPanel) {

    contentPanel.setLayout(
      new MigLayout(
        Panels.migXYLayout(),
        "[]10[][][]", // Column constraints
        "[]10[]10[]10[]" // Row constraints
      ));

    // Apply the theme
    contentPanel.setBackground(Themes.currentTheme.detailPanelBackground());

    // Create amount BTC label, text value is added in updateAmountCoin()
    amountBTCLabel = Labels.newValueLabel("");

    amountBTCValue = Labels.newValueLabel("");

    amountFiatLabel = Labels.newValueLabel(Languages.safeText(MessageKey.LOCAL_AMOUNT));
    amountFiatValue = Labels.newValueLabel("");

    miningFeePaidLabel = Labels.newValueLabel("");
    // Add bitcoin unit to mining fee label
    LabelDecorator.applyBitcoinSymbolLabel(
      miningFeePaidLabel,
      Configurations.currentConfiguration.getBitcoin(),
      Languages.safeText(MessageKey.TRANSACTION_FEE) + " ");
    miningFeePaidValue = Labels.newValueLabel("");

    miningFeePaidRateLabel = Labels.newValueLabel(Languages.safeText(MessageKey.TRANSACTION_FEE_RATE) + " " + Languages.TRANSACTION_FEE_RATE_UNIT);
    miningFeePaidRateValue = Labels.newValueLabel("");

    exchangeRateLabel = Labels.newValueLabel(Languages.safeText(MessageKey.EXCHANGE_RATE_LABEL));
    exchangeRateValue = Labels.newValueLabel("");

    update();

    contentPanel.add(amountBTCLabel);
    contentPanel.add(amountBTCValue, "wrap");

    contentPanel.add(amountFiatLabel);
    contentPanel.add(amountFiatValue, "wrap");

    contentPanel.add(exchangeRateLabel);
    contentPanel.add(exchangeRateValue, "wrap");

    contentPanel.add(miningFeePaidLabel);
    contentPanel.add(miningFeePaidValue, "wrap");

    contentPanel.add(miningFeePaidRateLabel);
    contentPanel.add(miningFeePaidRateValue, "wrap");
  }

  @Override
  protected void initialiseButtons(AbstractWizard<PaymentsWizardModel> wizard) {
    PanelDecorator.addExitCancelPreviousNext(this, wizard);
  }

  @Override
  public void afterShow() {

    getNextButton().requestFocusInWindow();
    ViewEvents.fireWizardButtonEnabledEvent(getPanelName(), WizardButton.NEXT, true);

    update();
  }

  @Override
  public void updateFromComponentModels(Optional componentModel) {
    // Do nothing
  }

  public void update() {

    PaymentData paymentData = getWizardModel().getPaymentData();

    if (paymentData != null) {
      LanguageConfiguration languageConfiguration = Configurations.currentConfiguration.getLanguage();
      BitcoinConfiguration bitcoinConfiguration = Configurations.currentConfiguration.getBitcoin();

      updateAmountCoin(paymentData, languageConfiguration, bitcoinConfiguration);

      updateAmountFiat(paymentData, languageConfiguration, bitcoinConfiguration);

      if (paymentData instanceof TransactionData) {
        TransactionData transactionData = (TransactionData) paymentData;

        // Get the transaction info again directly from the WalletService to make sure the mining fee is up to date
        // Otherwise use sentBySelf on corresponding transactionInfo
        Optional<Coin> miningFee = Optional.absent();

        Optional<WalletService> walletService = CoreServices.getCurrentWalletService();
        if (walletService.isPresent()) {
          TransactionInfo transactionInfo = walletService.get().getTransactionInfoByHash(transactionData.getTransactionId());

          if (transactionInfo != null) {
            miningFee = transactionInfo.getMinerFee();
          }
        }
        // Miner's fee
        updateMiningFee(languageConfiguration, bitcoinConfiguration, miningFee, transactionData.getSize());

        if (transactionData.getAmountCoin().or(Coin.ZERO).compareTo(Coin.ZERO) >= 0) {

          // Received bitcoin
          // Mining fee is not applicable
          miningFeePaidLabel.setVisible(false);
          miningFeePaidValue.setVisible(false);
          miningFeePaidRateLabel.setVisible(false);
          miningFeePaidRateValue.setVisible(false);
        } else {

          // Sent bitcoin
          miningFeePaidLabel.setVisible(true);
          miningFeePaidValue.setVisible(true);
          miningFeePaidRateLabel.setVisible(true);
          miningFeePaidRateValue.setVisible(true);
        }
      }

      if (paymentData.getAmountFiat() != null && paymentData.getAmountFiat().getCurrency().isPresent()) {
        // Add bitcoin unit to exchange rate label
        LabelDecorator.applyBitcoinSymbolLabel(
          exchangeRateLabel,
          Configurations.currentConfiguration.getBitcoin(),
          Languages.safeText(MessageKey.EXCHANGE_RATE_LABEL) + " " + paymentData.getAmountFiat().getCurrency().get().getCurrencyCode()
            + " / ");
      } else {
        exchangeRateLabel.setText(Languages.safeText(MessageKey.EXCHANGE_RATE_LABEL));
      }

      String exchangeRateText = "";
      if (paymentData.getAmountFiat() != null) {
        if (Strings.isNullOrEmpty(paymentData.getAmountFiat().getRate().or("")) || Strings.isNullOrEmpty(paymentData.getAmountFiat().getExchangeName().or(""))) {
          exchangeRateText = Languages.safeText(MessageKey.NOT_AVAILABLE);
        } else {
          // Convert the exchange rate (which is always stored as fiat currency per bitcoin) to match the unit of bitcoin being used
          String convertedExchangeRateText = Formats.formatExchangeRate(paymentData.getAmountFiat().getRate(), languageConfiguration, bitcoinConfiguration);
          exchangeRateText = convertedExchangeRateText + " (" + paymentData.getAmountFiat().getExchangeName().or("") + ")";
        }
      }
      exchangeRateValue.setText(exchangeRateText);
    }
  }

  private void updateMiningFee(LanguageConfiguration languageConfiguration, BitcoinConfiguration bitcoinConfiguration, Optional<Coin> miningFee, int transactionSize) {
    if (miningFee.isPresent()) {
      Coin miningFeeAsCoin = miningFee.get();
      String[] minerFeePaidArray = Formats.formatCoinAsSymbolic(miningFeeAsCoin.negate(), languageConfiguration, bitcoinConfiguration, true);
      miningFeePaidValue.setText(minerFeePaidArray[0] + minerFeePaidArray[1]);

      // Work out fee rate
      if (transactionSize > 0) {
        double feeRate = (double)miningFeeAsCoin.getValue() / transactionSize;
        miningFeePaidRateValue.setText(feeRateFormat.format(feeRate));
      } else {
        miningFeePaidRateValue.setText(Languages.safeText(MessageKey.NOT_AVAILABLE));
      }
    } else {
      miningFeePaidValue.setText(Languages.safeText(MessageKey.NOT_AVAILABLE));
      miningFeePaidRateValue.setText(Languages.safeText(MessageKey.NOT_AVAILABLE));
    }
  }

  private void updateAmountCoin(PaymentData paymentData, LanguageConfiguration languageConfiguration, BitcoinConfiguration bitcoinConfiguration) {
    Coin amountCoin = paymentData.getAmountCoin().or(Coin.ZERO);

    MessageKey messageKey = getMessageKeyForAmount(paymentData);

    // Add bitcoin unit to amount label
    LabelDecorator.applyBitcoinSymbolLabel(
      amountBTCLabel,
      Configurations.currentConfiguration.getBitcoin(),
      Languages.safeText(messageKey) + " ");

    String[] balanceArray = Formats.formatCoinAsSymbolic(amountCoin, languageConfiguration, bitcoinConfiguration, true);
    amountBTCValue.setText(balanceArray[0] + balanceArray[1]);
  }

  private void updateAmountFiat(PaymentData paymentData, LanguageConfiguration languageConfiguration, BitcoinConfiguration bitcoinConfiguration) {
    FiatPayment amountFiat = paymentData.getAmountFiat();
    if (amountFiat != null && amountFiat.getAmount().isPresent()) {
      amountFiatValue.setText((Formats.formatLocalAmount(amountFiat.getAmount().get(), languageConfiguration.getLocale(), bitcoinConfiguration, true)));
    } else {
      amountFiatValue.setText("");
    }

    MessageKey messageKey = getMessageKeyForAmount(paymentData);

    if (amountFiat != null && amountFiat.getCurrency().isPresent()) {
      amountFiatLabel = Labels.newValueLabel(Languages.safeText(messageKey) + "  " + amountFiat.getCurrency().get().getCurrencyCode());
    } else {
      amountFiatLabel = Labels.newValueLabel(Languages.safeText(messageKey));
    }
  }

  private MessageKey getMessageKeyForAmount(PaymentData paymentData) {
    Coin amountCoin = paymentData.getAmountCoin().or(Coin.ZERO);

    if (amountCoin.compareTo(Coin.ZERO) >= 0) {
      // Receive
      return MessageKey.LOCAL_AMOUNT;
    } else {
      // Send
      return MessageKey.LOCAL_AMOUNT_INCLUDING_FEES;
    }
  }
}
