package org.multibit.hd.ui.views.wizards.edit_wallet;

/**
 * <p>Enum to provide the following to "edit wallet" wizard model:</p>
 * <ul>
 * <li>State identification</li>
 * </ul>
 *
 * @since 0.0.1
 *
 */
public enum EditWalletState {

  EDIT_WALLET,

  // End of enum
  ;

}
