## Notes on the Swing UI

These notes are for developers looking to gain an overview of the entire application in preparation for providing a pull request.

## Getting started

For a super fast overview run up the `MultiBitHDFestTest` class as a standard JUnit test.

To begin your exploration of the code start with the main application entry point, `MultiBitHD`.

## UI principles

## Screens and Wizards



